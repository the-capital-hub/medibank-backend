---
name: Feature request
about: Suggest a feature for Redis
title: '[NEW]'
labels: ''
assignees: ''

---

**The problem/use-case that the feature addresses**

A description of the problem that the feature will solve, or the use-case with which the feature will be used.

**Description of the feature**

A description of what you want to happen.

**Alternatives you've considered**

Any alternative solutions or features you've considered, including references to existing open and closed feature requests in this repository.

**Additional information**

Any additional information that is relevant to the feature request.
